export interface TaskFilters {
  ESTATUS?: string;
  ASIGNACIÓN?: string;
  PRIORIDAD?: string;
}